import cookieParser from "cookie-parser";

const cookieParserMiddleware = cookieParser();

export default cookieParserMiddleware;
